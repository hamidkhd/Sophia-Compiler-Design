package main.symbolTable.utils.graph.exceptions;

public class NodeAlreadyExistsException extends Exception {
}
