package main.symbolTable.exceptions;

public class ItemAlreadyExistsException extends Exception {
}
