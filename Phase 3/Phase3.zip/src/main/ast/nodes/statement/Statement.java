package main.ast.nodes.statement;

import main.ast.nodes.Node;

public abstract class Statement extends Node {
}
