package main.ast.types;

public class NoType extends Type {
    @Override
    public String toString() {
        return "NoType";
    }
}