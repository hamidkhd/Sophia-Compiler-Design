package main.ast.types;

public class NullType extends Type {
    @Override
    public String toString() {
        return "NullType";
    }
}